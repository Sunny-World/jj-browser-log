
interface Window {
	XMLHttpRequest:any,
	DocumentTouch:any,
}
declare function ActiveXObject(s: string):void;
declare function DocumentTouch():any;

